package Global

import Global.ServiceCenter.*


object GlobalVariables {
  lazy val serviceCode : String = OrderServiceCode
  val projectIDLength:Int=20
  var isTest:Boolean=false

}
