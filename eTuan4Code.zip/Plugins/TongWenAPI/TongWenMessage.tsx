import { API } from 'Plugins/CommonUtils/Send/API'

export abstract class TongWenMessage extends API {
    override serviceName: string = 'Tong-Wen'
}
