export abstract class IDClass {
    constructor(public v: number) {}
}
