export const masterBranch = 'master'
