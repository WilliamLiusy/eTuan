package Global

import Global.ServiceCenter.*


object GlobalVariables {
  lazy val serviceCode : String = ProductServiceCode
  val projectIDLength:Int=20
  var isTest:Boolean=false

}
